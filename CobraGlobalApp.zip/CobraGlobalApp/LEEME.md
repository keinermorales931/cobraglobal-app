# CobraGlobal — App Android

App Android que abre la página de CobraGlobal dentro de una app propia: tu ícono, pantalla de carga, botón atrás, deslizar hacia abajo para recargar, apertura de WhatsApp, llamadas y correo, subida de archivos, descargas y una pantalla de "Sin conexión".

## Cómo generar el APK

1. Instala **Android Studio** (gratis): https://developer.android.com/studio
2. Descomprime este zip y en Android Studio elige **File › Open**. Selecciona la carpeta `CobraGlobalApp`.
3. Espera a que termine la sincronización ("Gradle sync"). La primera vez descarga varias cosas y puede tardar unos minutos.
4. Menú **Build › Build App Bundle(s) / APK(s) › Build APK(s)**.
5. Cuando termine, pulsa **locate** en el aviso. El archivo queda en:
   `app/build/outputs/apk/debug/app-debug.apk`
6. Pasa ese APK a tu celular e instálalo. Android te pedirá permitir "instalar apps de origen desconocido".

Para probarla sin generar el APK, conecta tu celular por USB con la depuración USB activada y pulsa ▶ (Run).

## Cambiar la dirección de la página

Ahora apunta a tu enlace de ngrok:

```
https://jogger-canine-willow.ngrok-free.dev
```

**Importante:** con ngrok la app solo funciona mientras tu PC esté encendido y ngrok corriendo. Cuando publiques la página en un hosting con dominio propio, cambia la dirección en `app/build.gradle.kts`:

```kotlin
buildConfigField("String", "BASE_URL", "\"https://www.tu-dominio.com\"")
```

y vuelve a generar el APK. La dirección debe empezar por `https://`.

## Versión para Google Play

El APK *debug* sirve para probar. Para publicar en Google Play:

1. **Build › Generate Signed App Bundle / APK** → elige **Android App Bundle** → crea una llave (*keystore*). Guarda la llave y sus contraseñas: sin ellas no podrás actualizar la app.
2. Sube el `.aab` a Google Play Console. Necesitas cuenta de desarrollador, política de privacidad, una opción para eliminar la cuenta y el formulario de seguridad de datos. Como la app maneja deudas y pagos, revisa también las políticas de Google Play para apps financieras.
3. Para cada actualización, sube `versionCode` y `versionName` en `app/build.gradle.kts`.

## Qué hace cada parte

| Archivo | Para qué sirve |
|---|---|
| `app/build.gradle.kts` | Dirección de la página, versión y nombre del paquete (`com.cobraglobal.app`) |
| `app/src/main/java/.../MainActivity.kt` | Carga la página, enlaces externos, archivos, descargas, botón atrás |
| `app/src/main/res/values/colors.xml` | Colores de CobraGlobal |
| `app/src/main/res/values/strings.xml` | Textos de la app |
| `app/src/main/res/mipmap-*` y `drawable-nodpi` | Ícono y logo de la pantalla de carga |

## Limitaciones de esta versión

- No tiene notificaciones push. Para avisar de visitas o pagos con la app cerrada hace falta Firebase Cloud Messaging y cambios en el servidor.
- Si el estado de cuenta en CSV se genera en el navegador (con un enlace `blob:`), la descarga no funcionará dentro de la app. Funciona si el servidor envía el CSV como archivo.
- El ícono sale de una captura de pantalla. Para mejor nitidez, reemplaza `app/src/main/res/drawable-nodpi/ic_launcher_foreground.png` (432×432 px, logo centrado en el 60 % del cuadro) con tu logo original. También puedes usar **File › New › Image Asset** en Android Studio.
