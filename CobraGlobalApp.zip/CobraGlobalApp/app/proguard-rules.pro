# Reglas de ProGuard/R8 para la versión de publicación.
# La app no usa reflexión ni interfaces JavaScript, así que no necesita reglas extra.
