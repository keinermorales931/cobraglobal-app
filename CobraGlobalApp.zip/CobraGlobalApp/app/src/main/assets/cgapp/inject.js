(function () {
  'use strict';
  if (window.__cgApp) return;
  window.__cgApp = true;

  var LOGIN = '/__cgapp/login.html';
  var esInicio = location.pathname === '/' || location.pathname === '/index.html';
  var SECCIONES = ['inicio', 'quienes', 'tradicionales', 'innovadores', 'miembros', 'afiliados', 'vender'];

  var estilo = document.createElement('style');
  estilo.textContent = [
    // En la app no se ve el sitio público: solo el panel
    'html.cg-app .topbar, html.cg-app .menu, html.cg-app .quick, html.cg-app footer.pie,',
    'html.cg-app #portalSitio { display: none !important; }',
    'html.cg-app body:not(.en-portal) > *:not(dialog):not(.panel-pista):not(#cgVolver) { visibility: hidden; }',
    'html.cg-app body.en-portal .head { justify-content: center; }',
    // Excepción: una sección que el panel abre a propósito (p. ej. "Ir a vender cartera") se muestra sola
    'html.cg-app.cg-seccion body:not(.en-portal) > *:not(.cg-mostrar):not(dialog):not(.panel-pista):not(#cgVolver) { display: none !important; }',
    'html.cg-app.cg-seccion body:not(.en-portal) > .cg-mostrar { visibility: visible !important; display: block !important; }',
    '#cgVolver { display: none; }',
    'html.cg-app.cg-seccion body:not(.en-portal) #cgVolver { display: flex; position: sticky; top: 0; z-index: 900; width: 100%;',
    '  align-items: center; gap: 8px; border: 0; margin: 0; padding: 14px 18px; background: #0D2148; color: #fff;',
    '  font: inherit; font-weight: 600; font-size: 1rem; text-align: left; cursor: pointer; box-shadow: 0 2px 10px rgba(0,0,0,.18); }'
  ].join('\n');
  (document.head || document.documentElement).appendChild(estilo);
  document.documentElement.classList.add('cg-app');

  if (!esInicio) return;

  var raiz = document.documentElement;
  function enSeccion() { return raiz.classList.contains('cg-seccion'); }

  function mostrarSeccion(id) {
    var sec = document.getElementById(id);
    if (!sec) return;
    var previas = document.querySelectorAll('.cg-mostrar');
    for (var i = 0; i < previas.length; i++) previas[i].classList.remove('cg-mostrar');
    sec.classList.add('cg-mostrar');
    raiz.classList.add('cg-seccion');
    setTimeout(function () { window.scrollTo(0, 0); }, 60);
  }

  function cerrarSeccion() {
    raiz.classList.remove('cg-seccion');
    var previas = document.querySelectorAll('.cg-mostrar');
    for (var i = 0; i < previas.length; i++) previas[i].classList.remove('cg-mostrar');
  }

  function volverAlPanel() {
    cerrarSeccion();
    var boton = document.querySelector('#btnPanel, .btn-panel');
    if (boton) boton.click();
    window.scrollTo(0, 0);
  }

  window.__cgAtras = function () { if (!enSeccion()) return false; volverAlPanel(); return true; };

  // Botones del panel que llevan a una sección del sitio
  document.addEventListener('click', function (e) {
    var t = e.target;
    if (!t || !t.closest) return;
    if (t.closest('#cgVolver')) { e.preventDefault(); volverAlPanel(); return; }
    if (t.closest('[data-a-vender]')) { mostrarSeccion('vender'); return; }
    var enlace = t.closest('a[href^="#"]');
    if (enlace && document.body.classList.contains('en-portal')) {
      var id = (enlace.getAttribute('href') || '').slice(1);
      if (SECCIONES.indexOf(id) !== -1) mostrarSeccion(id);
    }
  }, true);

  function crearVolver() {
    if (document.getElementById('cgVolver')) return;
    var b = document.createElement('button');
    b.type = 'button';
    b.id = 'cgVolver';
    b.textContent = '←  Volver a mi panel';
    document.body.insertBefore(b, document.body.firstChild);
  }

  var revisando = false;
  function revisar() {
    if (revisando || !document.body) return;
    if (document.body.classList.contains('en-portal')) { if (enSeccion()) cerrarSeccion(); return; }
    if (document.querySelector('dialog[open]')) return;
    revisando = true;
    fetch('/api/yo', { credentials: 'same-origin' })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        if (!d.usuario || d.usuario.debe_cambiar) { location.replace(LOGIN); return; }
        if (enSeccion()) return;   // está viendo a propósito una sección (p. ej. vender cartera)
        if (!document.body.classList.contains('en-portal')) {
          var boton = document.querySelector('#btnPanel, .btn-panel');
          if (boton) boton.click();
        }
      })
      .catch(function () {})
      .then(function () { revisando = false; });
  }

  var temporizador = 0;
  function programar(ms) { clearTimeout(temporizador); temporizador = setTimeout(revisar, ms); }
  function vigilar() {
    crearVolver();
    new MutationObserver(function () { programar(600); })
      .observe(document.body, { attributes: true, attributeFilter: ['class'] });
    programar(1800);
  }
  if (document.body) vigilar(); else document.addEventListener('DOMContentLoaded', vigilar);
})();
