/* CobraGlobal App: ajustes que la app aplica a la página SOLO dentro de la aplicación.
   No cambia la página en el servidor: en el navegador se sigue viendo igual. */
(function () {
  'use strict';
  if (window.__cgApp) return;
  window.__cgApp = true;

  var LOGIN = '/__cgapp/login.html';
  var esInicio = location.pathname === '/' || location.pathname === '/index.html';

  // 1. Ocultar el contenido público (portada, menú, pie) y el botón "Ver sitio público"
  var estilo = document.createElement('style');
  estilo.textContent = [
    'html.cg-app .topbar, html.cg-app .menu, html.cg-app .quick, html.cg-app footer.pie,',
    'html.cg-app #portalSitio { display: none !important; }',
    'html.cg-app body:not(.en-portal) > *:not(dialog):not(.panel-pista) { visibility: hidden; }',
    'html.cg-app body.en-portal .head { justify-content: center; }'
  ].join('\n');
  (document.head || document.documentElement).appendChild(estilo);
  document.documentElement.classList.add('cg-app');

  if (!esInicio) return; // otras páginas (por ejemplo, Educación financiera) se muestran tal cual

  // 2. Si no hay sesión (o se pulsó "Salir"), volver a la pantalla de inicio de sesión de la app
  var revisando = false;
  function revisar() {
    if (revisando || !document.body || document.body.classList.contains('en-portal')) return;
    if (document.querySelector('dialog[open]')) return; // por ejemplo, el cambio de clave temporal
    revisando = true;
    fetch('/api/yo', { credentials: 'same-origin' })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        if (!d.usuario || d.usuario.debe_cambiar) location.replace(LOGIN);
        else if (!document.body.classList.contains('en-portal')) {
          var boton = document.querySelector('#btnPanel, .btn-panel');
          if (boton) boton.click();
        }
      })
      .catch(function () { /* sin conexión: la app muestra su aviso */ })
      .then(function () { revisando = false; });
  }

  var temporizador = 0;
  function programar(ms) { clearTimeout(temporizador); temporizador = setTimeout(revisar, ms); }

  function vigilar() {
    new MutationObserver(function () { programar(600); })
      .observe(document.body, { attributes: true, attributeFilter: ['class'] });
    programar(1800); // la página tarda un momento en abrir el panel después de cargar
  }
  if (document.body) vigilar();
  else document.addEventListener('DOMContentLoaded', vigilar);
})();
