package com.cobraglobal.app

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.View
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var swipe: SwipeRefreshLayout
    private lateinit var progress: ProgressBar
    private lateinit var offline: LinearLayout

    private val baseUrl: String = BuildConfig.BASE_URL.trimEnd('/')
    private val baseHost: String = Uri.parse(BuildConfig.BASE_URL).host.orEmpty()

    /** Pantalla de inicio de sesión propia de la app (vive dentro del APK, carpeta assets/cgapp). */
    private val loginUrl: String get() = "$baseUrl$APP_PREFIX" + "login.html"

    /** Ajustes que la app aplica a la página solo dentro de la aplicación (assets/cgapp/inject.js). */
    private val injectScript: String by lazy {
        assets.open("cgapp/inject.js").bufferedReader().use { it.readText() }
    }

    /** La pantalla de carga se mantiene hasta que la página termina de cargar la primera vez. */
    private var firstLoadDone = false

    /** Callback pendiente del selector de archivos (por ejemplo, subir una cartera). */
    private var fileCallback: ValueCallback<Array<Uri>>? = null

    private val filePicker = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val uris = WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
        fileCallback?.onReceiveValue(uris)
        fileCallback = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        val splash = installSplashScreen()
        super.onCreate(savedInstanceState)
        splash.setKeepOnScreenCondition { !firstLoadDone }

        setContentView(R.layout.activity_main)
        webView = findViewById(R.id.webview)
        swipe = findViewById(R.id.swipe)
        progress = findViewById(R.id.progress)
        offline = findViewById(R.id.offline)

        setupEdgeToEdge()
        setupWebView()
        setupSwipe()
        setupBackButton()

        findViewById<Button>(R.id.retry).setOnClickListener {
            offline.visibility = View.GONE
            webView.reload()
        }

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState)
            firstLoadDone = true
        } else {
            webView.loadUrl(loginUrl)
        }
    }

    /** Android 15 dibuja la app bajo la barra de estado: dejamos ese espacio en azul marino. */
    private fun setupEdgeToEdge() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val root = findViewById<View>(R.id.root)
        WindowCompat.getInsetsController(window, root).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = true
        }
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime()
            )
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            WindowInsetsCompat.CONSUMED
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(webView, false)
        }

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true          // LocalStorage de la página
            databaseEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
            builtInZoomControls = false
            displayZoomControls = false
            allowFileAccess = false
            allowContentAccess = false
            mediaPlaybackRequiresUserGesture = true
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            cacheMode = WebSettings.LOAD_DEFAULT

            // ngrok gratis muestra una página de aviso a los navegadores normales.
            // Con un identificador propio la app entra directo. Al pasar a un dominio
            // propio, la app usa el identificador normal del navegador.
            if (baseHost.contains("ngrok")) {
                userAgentString = "CobraGlobalAndroid/1.0"
            }
        }

        webView.webViewClient = object : WebViewClient() {

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                return handleExternalLink(request.url)
            }

            /**
             * Las direcciones /__cgapp/... se sirven desde el APK como si fueran del mismo sitio.
             * Así la pantalla de ingreso usa la misma API y la misma sesión (cookies) que la página,
             * sin cambiar nada en el servidor.
             */
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val url = request.url
                val path = url.path.orEmpty()
                if (!url.host.equals(baseHost, ignoreCase = true) || !path.startsWith(APP_PREFIX)) return null
                val nombre = path.removePrefix(APP_PREFIX).ifEmpty { "login.html" }
                if (nombre.contains("..")) return null
                val mime = when (nombre.substringAfterLast('.').lowercase()) {
                    "html" -> "text/html"
                    "js" -> "application/javascript"
                    "css" -> "text/css"
                    "png" -> "image/png"
                    "svg" -> "image/svg+xml"
                    else -> "application/octet-stream"
                }
                return try {
                    WebResourceResponse(
                        mime, "UTF-8", 200, "OK",
                        mapOf("Cache-Control" to "no-store"),
                        assets.open("cgapp/$nombre")
                    )
                } catch (e: Exception) {
                    WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", emptyMap(), "".byteInputStream())
                }
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                progress.visibility = View.VISIBLE
            }

            override fun onPageCommitVisible(view: WebView, url: String?) {
                aplicarAjustes(view, url)
            }

            override fun onPageFinished(view: WebView, url: String?) {
                aplicarAjustes(view, url)
                progress.visibility = View.GONE
                swipe.isRefreshing = false
                firstLoadDone = true
                CookieManager.getInstance().flush()
            }

            override fun onReceivedError(
                view: WebView,
                request: WebResourceRequest,
                error: WebResourceError
            ) {
                // Solo mostramos "Sin conexión" si falla la página principal, no una imagen suelta.
                if (request.isForMainFrame) {
                    offline.visibility = View.VISIBLE
                    swipe.isRefreshing = false
                    firstLoadDone = true
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                progress.progress = newProgress
                if (newProgress >= 100) progress.visibility = View.GONE
            }

            override fun onShowFileChooser(
                view: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: WebChromeClient.FileChooserParams
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                return try {
                    filePicker.launch(Intent.createChooser(params.createIntent(), getString(R.string.choose_file)))
                    true
                } catch (e: ActivityNotFoundException) {
                    fileCallback = null
                    toast(R.string.no_app)
                    false
                }
            }
        }

        // Descargas (por ejemplo, el estado de cuenta en CSV si el servidor lo envía como archivo)
        webView.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            if (!url.startsWith("http")) {
                toast(R.string.no_app)
                return@setDownloadListener
            }
            val fileName = URLUtil.guessFileName(url, contentDisposition, mimeType)
            val req = DownloadManager.Request(Uri.parse(url)).apply {
                setMimeType(mimeType)
                addRequestHeader("User-Agent", userAgent)
                CookieManager.getInstance().getCookie(url)?.let { addRequestHeader("Cookie", it) }
                setTitle(fileName)
                setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
            }
            (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
            toast(R.string.download_started)
        }
    }

    /** En las páginas del sitio (no en la pantalla de ingreso) oculta la portada y vigila la sesión. */
    private fun aplicarAjustes(view: WebView, url: String?) {
        val uri = Uri.parse(url ?: return)
        if (!uri.host.equals(baseHost, ignoreCase = true)) return
        if (uri.path.orEmpty().startsWith(APP_PREFIX)) return
        view.evaluateJavascript(injectScript, null)
    }

    /**
     * Las páginas de CobraGlobal se abren dentro de la app.
     * WhatsApp, llamadas, correo y sitios externos se abren con la app que corresponda.
     * Devuelve true si el enlace se abrió fuera.
     */
    private fun handleExternalLink(uri: Uri): Boolean {
        val scheme = uri.scheme?.lowercase().orEmpty()
        val host = uri.host?.lowercase().orEmpty()

        if ((scheme == "https" || scheme == "http") && host == baseHost.lowercase()) {
            return false // es tu página: se queda en la app
        }

        val intent = when (scheme) {
            "tel" -> Intent(Intent.ACTION_DIAL, uri)
            "mailto" -> Intent(Intent.ACTION_SENDTO, uri)
            "intent" -> try {
                // Enlaces intent:// solo se abren como navegación segura (sin componentes fijos)
                Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME).apply {
                    addCategory(Intent.CATEGORY_BROWSABLE)
                    component = null
                    selector = null
                }
            } catch (e: Exception) {
                null
            }
            else -> Intent(Intent.ACTION_VIEW, uri) // whatsapp://, wa.me, otros sitios
        }

        if (intent == null) return true
        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            toast(R.string.no_app)
        }
        return true
    }

    private fun setupSwipe() {
        swipe.setColorSchemeResources(R.color.navy, R.color.gold)
        // Solo se recarga al deslizar si la página está arriba del todo
        swipe.setOnChildScrollUpCallback { _, _ -> webView.scrollY > 0 }
        swipe.setOnRefreshListener {
            offline.visibility = View.GONE
            webView.reload()
        }
    }

    private fun setupBackButton() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                // Si está viendo una sección abierta desde el panel (p. ej. vender cartera), "atrás" vuelve al panel
                webView.evaluateJavascript("(window.__cgAtras && window.__cgAtras()) === true") { r ->
                    if (r == "true") return@evaluateJavascript
                    if (webView.canGoBack()) {
                        webView.goBack()
                    } else {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                        isEnabled = true
                    }
                }
            }
        })
    }

    companion object {
        private const val APP_PREFIX = "/__cgapp/"
    }

    private fun toast(res: Int) = Toast.makeText(this, res, Toast.LENGTH_SHORT).show()

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
    }

    override fun onPause() {
        webView.onPause()
        CookieManager.getInstance().flush()
        super.onPause()
    }

    override fun onDestroy() {
        fileCallback?.onReceiveValue(null)
        webView.destroy()
        super.onDestroy()
    }
}
